from difflib import SequenceMatcher

from normalize import normalize_title_for_dedupe, slugify_title


def dedupe_results(results):
    deduped = []
    exact_seen = set()

    for item in results:
        title_key = normalize_title_for_dedupe(item.get("title", ""))
        url_key = (item.get("url") or "").strip().lower()
        exact_key = (title_key, url_key)
        if exact_key in exact_seen:
            continue

        slug = slugify_title(item.get("title", ""))
        duplicate = False
        for existing in deduped:
            existing_title = normalize_title_for_dedupe(existing.get("title", ""))
            existing_slug = slugify_title(existing.get("title", ""))
            if slug and existing_slug and slug == existing_slug:
                duplicate = True
                break
            if title_key and existing_title:
                ratio = SequenceMatcher(None, title_key, existing_title).ratio()
                if ratio >= 0.96:
                    duplicate = True
                    break
        if duplicate:
            continue

        exact_seen.add(exact_key)
        deduped.append(item)

    return deduped
