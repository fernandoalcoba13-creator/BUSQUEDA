import hashlib
import os
import tempfile
from pathlib import Path
from typing import List, Optional
from urllib.parse import quote

from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from base import close_http_client, fetch_bytes, get_project_root
from cache import clear_cache, purge_expired_cache
from image_service import search_by_image
from search_service import search_all

PROJECT_ROOT = get_project_root()
STATIC_DIR = PROJECT_ROOT / "static"
IMAGE_CACHE_DIR = PROJECT_ROOT / "image_cache"
STATIC_DIR.mkdir(exist_ok=True)
IMAGE_CACHE_DIR.mkdir(exist_ok=True)

app = FastAPI(title="Kmorra Search API", version="3.0.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ALLOW_ORIGINS", "*").split(","),
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    await purge_expired_cache()


@app.on_event("shutdown")
async def shutdown_event():
    await close_http_client()


@app.get("/")
async def root():
    return {"status": "ok", "message": "Kmorra Search API running", "version": "3.0.0"}


@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "3.0.0"}


@app.get("/api/search")
async def api_search(
    q: str = Query(..., min_length=1, description="Texto de búsqueda"),
    filter: str = Query("all", description="Filtro general"),
    platforms: Optional[str] = Query(None, description="thingiverse,printables,myminifactory,makerworld,cults3d"),
    limit: int = Query(30, ge=1, le=100),
):
    try:
        platform_list: Optional[List[str]] = None
        if platforms:
            platform_list = [p.strip().lower() for p in platforms.split(",") if p.strip()]

        results = await search_all(query=q, filter_by=filter, platforms=platform_list, limit=limit)
        if isinstance(results, dict):
            return JSONResponse(content=results)

        platform_stats = {key: 0 for key in ["thingiverse", "printables", "myminifactory", "makerworld", "cults3d"]}
        for item in results:
            platform = str(item.get("platform", "")).lower()
            if platform in platform_stats:
                platform_stats[platform] += 1

        return JSONResponse(
            content={
                "query": q,
                "filter": filter,
                "total": len(results),
                "platform_stats": platform_stats,
                "results": results,
            }
        )
    except Exception as e:
        print(f"[ERROR] /api/search failed: {e}")
        raise HTTPException(status_code=500, detail=f"Search error: {str(e)}")


@app.post("/api/search-by-image")
async def api_search_by_image(
    image: UploadFile = File(...),
    filter: str = Query("all"),
    platforms: Optional[str] = Query(None),
    limit: int = Query(30, ge=1, le=100),
):
    temp_path = None
    try:
        if not image:
            raise HTTPException(status_code=400, detail="No image uploaded")

        suffix = os.path.splitext(image.filename or "upload.jpg")[1] or ".jpg"
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            content = await image.read()
            tmp.write(content)
            temp_path = tmp.name

        platform_list: Optional[List[str]] = None
        if platforms:
            platform_list = [p.strip().lower() for p in platforms.split(",") if p.strip()]

        results = await search_by_image(image_path=temp_path, filter_by=filter, platforms=platform_list, limit=limit)
        if isinstance(results, dict):
            return JSONResponse(content=results)

        platform_stats = {key: 0 for key in ["thingiverse", "printables", "myminifactory", "makerworld", "cults3d"]}
        detected_query = results[0].get("_detected_query") if results else None

        clean_results = []
        for item in results:
            row = dict(item)
            row.pop("_detected_query", None)
            platform = str(row.get("platform", "")).lower()
            if platform in platform_stats:
                platform_stats[platform] += 1
            clean_results.append(row)

        return JSONResponse(
            content={
                "detected_query": detected_query,
                "filter": filter,
                "total": len(clean_results),
                "platform_stats": platform_stats,
                "results": clean_results,
            }
        )
    except Exception as e:
        print(f"[ERROR] /api/search-by-image failed: {e}")
        raise HTTPException(status_code=500, detail=f"Image search error: {str(e)}")
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)


@app.get("/api/image-proxy")
async def image_proxy(url: str = Query(..., min_length=5)):
    digest = hashlib.sha1(url.encode("utf-8")).hexdigest()
    target = IMAGE_CACHE_DIR / digest
    if target.exists():
        return FileResponse(target)
    try:
        content = await fetch_bytes(url)
        target.write_bytes(content)
        return FileResponse(target)
    except Exception as e:
        print(f"[image-proxy] error: {e}")
        raise HTTPException(status_code=400, detail="No se pudo descargar la imagen")


@app.post("/api/cache/clear")
async def api_clear_cache():
    await clear_cache()
    return {"status": "ok", "message": "Cache limpiada"}
