import asyncio
import os
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin, urlparse

import httpx

DEFAULT_HEADERS = {
    "User-Agent": os.getenv(
        "SCRAPER_USER_AGENT",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
    ),
    "Accept-Language": "es-AR,es;q=0.9,en;q=0.8",
}

_HTTP_CLIENT: Optional[httpx.AsyncClient] = None
_HTTP_LOCK = asyncio.Lock()


def get_project_root() -> Path:
    return Path(__file__).resolve().parent


async def get_http_client() -> httpx.AsyncClient:
    global _HTTP_CLIENT
    if _HTTP_CLIENT is None or _HTTP_CLIENT.is_closed:
        async with _HTTP_LOCK:
            if _HTTP_CLIENT is None or _HTTP_CLIENT.is_closed:
                timeout = httpx.Timeout(
                    connect=float(os.getenv("HTTP_CONNECT_TIMEOUT", "5")),
                    read=float(os.getenv("HTTP_READ_TIMEOUT", "10")),
                    write=float(os.getenv("HTTP_WRITE_TIMEOUT", "10")),
                    pool=float(os.getenv("HTTP_POOL_TIMEOUT", "5")),
                )
                limits = httpx.Limits(
                    max_keepalive_connections=int(os.getenv("HTTP_KEEPALIVE", "20")),
                    max_connections=int(os.getenv("HTTP_MAX_CONNECTIONS", "50")),
                )
                _HTTP_CLIENT = httpx.AsyncClient(
                    timeout=timeout,
                    follow_redirects=True,
                    headers=DEFAULT_HEADERS,
                    limits=limits,
                )
    return _HTTP_CLIENT


async def close_http_client() -> None:
    global _HTTP_CLIENT
    if _HTTP_CLIENT and not _HTTP_CLIENT.is_closed:
        await _HTTP_CLIENT.aclose()
    _HTTP_CLIENT = None


async def fetch_text(url: str, *, headers: Optional[dict] = None) -> str:
    client = await get_http_client()
    response = await client.get(url, headers=headers)
    response.raise_for_status()
    return response.text


async def fetch_json(url: str, *, headers: Optional[dict] = None):
    client = await get_http_client()
    response = await client.get(url, headers=headers)
    response.raise_for_status()
    return response.json()


async def fetch_bytes(url: str, *, headers: Optional[dict] = None) -> bytes:
    client = await get_http_client()
    response = await client.get(url, headers=headers)
    response.raise_for_status()
    return response.content


async def is_image_url_ok(url: Optional[str]) -> bool:
    if not url:
        return False
    try:
        client = await get_http_client()
        response = await client.head(url)
        content_type = response.headers.get("content-type", "")
        if response.status_code < 400 and "image" in content_type:
            return True
    except Exception:
        pass
    return False


def normalize_url(url: Optional[str], base_url: Optional[str] = None) -> Optional[str]:
    if not url:
        return None
    url = url.strip()
    if not url:
        return None
    if url.startswith("data:"):
        return None
    if url.startswith("//"):
        return f"https:{url}"
    if base_url:
        return urljoin(base_url, url)
    return url


def clean_text(text: Optional[str]) -> str:
    return " ".join((text or "").split()).strip()


def looks_like_placeholder(url: Optional[str]) -> bool:
    if not url:
        return True
    value = url.lower()
    bad_tokens = [
        "placeholder",
        "default",
        "blank",
        "fallback",
        "no-image",
        "data:image",
    ]
    return any(token in value for token in bad_tokens)


def safe_slug(text: str) -> str:
    import re

    text = (text or "").strip().lower()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-") or "item"


def extract_best_image(tag, base_url: str) -> Optional[str]:
    if tag is None:
        return None
    candidates = []
    img = tag if getattr(tag, "name", None) == "img" else tag.find("img")
    if img:
        for attr in ("src", "data-src", "data-lazy-src", "data-original", "data-image", "srcset", "data-srcset"):
            raw = img.get(attr)
            if not raw:
                continue
            if attr in ("srcset", "data-srcset"):
                for part in raw.split(","):
                    piece = part.strip().split(" ")[0]
                    url = normalize_url(piece, base_url)
                    if url:
                        candidates.append(url)
            else:
                url = normalize_url(raw, base_url)
                if url:
                    candidates.append(url)
    for candidate in candidates:
        if not looks_like_placeholder(candidate):
            return candidate
    return candidates[0] if candidates else None


def host_from_url(url: str) -> str:
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ""
