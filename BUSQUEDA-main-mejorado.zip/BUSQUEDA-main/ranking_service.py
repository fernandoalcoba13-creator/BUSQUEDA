from normalize import normalize_text
from base import looks_like_placeholder


def rank_results(results, query):
    q = normalize_text(query)
    terms = [t for t in q.split() if t]

    def score(item):
        title = normalize_text(item.get("title", ""))
        price = normalize_text(str(item.get("price", "")))
        image = item.get("image")
        s = 0

        if q and title == q:
            s += 220
        if q and title.startswith(q):
            s += 140
        if q and q in title:
            s += 110

        if terms:
            overlap = sum(1 for term in terms if term in title)
            s += overlap * 28

        if image and not looks_like_placeholder(image):
            s += 35
        elif image:
            s += 5

        platform = normalize_text(item.get("platform", ""))
        if platform:
            s += 10

        if price in ("free", "gratis", "0", "0.0"):
            s += 8
        if item.get("_provider_position") is not None:
            s += max(0, 15 - int(item.get("_provider_position", 0)))

        return s

    return sorted(results, key=score, reverse=True)
