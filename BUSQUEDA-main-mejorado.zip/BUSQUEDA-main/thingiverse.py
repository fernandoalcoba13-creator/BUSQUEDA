import os
from urllib.parse import quote_plus

from bs4 import BeautifulSoup

from base import clean_text, extract_best_image, fetch_json, fetch_text, normalize_url

BASE_URL = "https://www.thingiverse.com"
API_BASE = "https://api.thingiverse.com"
PLACEHOLDER = "/static/no-image.svg"


async def _search_api(query: str):
    token = os.getenv("THINGIVERSE_TOKEN", "").strip()
    if not token:
        return []
    url = f"{API_BASE}/search/{quote_plus(query.strip())}?type=things&per_page=12&sort=relevant"
    try:
        data = await fetch_json(url, headers={"Authorization": f"Bearer {token}", "User-Agent": "KMORRA-STLGO/2.0"})
    except Exception as e:
        print(f"[thingiverse/api] error: {e}")
        return []

    results = []
    for item in data:
        image = item.get("thumbnail") or item.get("default_image", {}).get("url") or PLACEHOLDER
        results.append(
            {
                "title": item.get("name", "Sin título"),
                "url": f"{BASE_URL}/thing:{item.get('id', '')}",
                "platform": "thingiverse",
                "image": image,
                "price": "free",
                "_provider_position": len(results) + 1,
            }
        )
    return results


async def _search_html(query: str):
    url = f"{BASE_URL}/search?q={quote_plus(query.strip())}&page=1&type=things"
    try:
        html = await fetch_text(url)
    except Exception as e:
        print(f"[thingiverse/html] error: {e}")
        return []

    soup = BeautifulSoup(html, "html.parser")
    results = []
    seen = set()

    for a in soup.find_all("a", href=True):
        href = a["href"]
        if "/thing:" not in href:
            continue
        full_url = normalize_url(href, BASE_URL)
        if not full_url or full_url in seen:
            continue
        seen.add(full_url)

        title = clean_text(a.get_text(" ", strip=True))
        if not title:
            title = full_url.rstrip("/").split("/")[-1].replace("-", " ").strip()

        image = extract_best_image(a, BASE_URL)
        if not image and a.parent:
            image = extract_best_image(a.parent, BASE_URL)

        results.append(
            {
                "title": title,
                "url": full_url,
                "platform": "thingiverse",
                "image": image or PLACEHOLDER,
                "price": "free",
                "_provider_position": len(results) + 1,
            }
        )
        if len(results) >= 12:
            break
    return results


async def search(query: str):
    results = await _search_api(query)
    if not results:
        results = await _search_html(query)
    print(f"[thingiverse] '{query}' -> {len(results)} resultados")
    return results
