import asyncio
import os

import cults3d
import makerworld
import myminifactory
import printables
import thingiverse
from cache import get_cached_results, set_cached_results
from dedupe import dedupe_results
from fallback_service import fallback_search
from normalize import build_cache_key, normalize_query
from ranking_service import rank_results

_PROVIDER_TIMEOUT = float(os.getenv("PROVIDER_TIMEOUT", "10"))
_PROVIDER_CONCURRENCY = int(os.getenv("PROVIDER_CONCURRENCY", "5"))
_SEMAPHORE = asyncio.Semaphore(_PROVIDER_CONCURRENCY)


async def _run_provider(provider_module, query: str):
    try:
        async with _SEMAPHORE:
            result = provider_module.search(query)
            if asyncio.iscoroutine(result):
                result = await asyncio.wait_for(result, timeout=_PROVIDER_TIMEOUT)
            count = len(result or [])
            print(f"[PROVIDER] {provider_module.__name__} -> {count} resultados para '{query}'")
            return result or []
    except Exception as e:
        print(f"[WARN] Provider failed: {provider_module.__name__}: {e}")
        return []


async def search_all(query: str, filter_by: str = "all", platforms=None, limit: int = 30):
    normalized_query = normalize_query(query)
    cache_key = build_cache_key(normalized_query, filter_by, platforms, limit)

    cached = await get_cached_results(cache_key)
    if cached:
        print(f"[CACHE] hit para '{normalized_query}' -> {len(cached)} resultados")
        return cached[:limit]

    provider_map = {
        "thingiverse": thingiverse,
        "printables": printables,
        "myminifactory": myminifactory,
        "makerworld": makerworld,
        "cults3d": cults3d,
    }

    if platforms:
        selected = [p for p in platforms if p in provider_map]
    else:
        selected = list(provider_map.keys())

    print(f"[SEARCH] query='{normalized_query}' platforms={selected} filter={filter_by}")
    tasks = [_run_provider(provider_map[name], normalized_query) for name in selected]
    provider_results = await asyncio.gather(*tasks)

    results = []
    for batch in provider_results:
        if batch:
            results.extend(batch)

    print(f"[SEARCH] total bruto -> {len(results)} resultados")

    results = dedupe_results(results)
    print(f"[SEARCH] después de dedupe -> {len(results)} resultados")

    results = rank_results(results, normalized_query)
    if not results:
        results = fallback_search(normalized_query)

    results = results[:limit]

    try:
        await set_cached_results(cache_key, results)
    except Exception as e:
        print(f"[WARN] Cache save failed: {e}")

    return results
