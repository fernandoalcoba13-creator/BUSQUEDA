import hashlib
import re
from urllib.parse import quote_plus


def normalize_text(text: str) -> str:
    if not text:
        return ""
    text = text.lower().strip()
    text = re.sub(r"\s+", " ", text)
    return text


normalize_query = normalize_text


def normalize_title_for_dedupe(title: str) -> str:
    if not title:
        return ""
    title = normalize_text(title)
    title = re.sub(r"[^a-z0-9\s]", "", title)
    title = re.sub(r"\b(stl|3d|model|printable|printing|free)\b", " ", title)
    title = re.sub(r"\s+", " ", title).strip()
    return title


def slugify_title(title: str) -> str:
    title = normalize_title_for_dedupe(title)
    return title.replace(" ", "-")


def build_query_variants(query: str):
    q = normalize_query(query)
    variants = [q]
    if "stl" not in q:
        variants.append(f"{q} stl")
    if "3d" not in q:
        variants.append(f"{q} 3d")
    if "model" not in q:
        variants.append(f"{q} model")
    seen = set()
    clean = []
    for v in variants:
        if v and v not in seen:
            seen.add(v)
            clean.append(v)
    return clean


def encode_q(query: str) -> str:
    return quote_plus(query or "")


def build_cache_key(query: str, filter_by: str, platforms, limit: int) -> str:
    normalized_platforms = ",".join(sorted([p.strip().lower() for p in (platforms or []) if p])) or "all"
    raw = f"q={normalize_query(query)}|filter={normalize_query(filter_by)}|platforms={normalized_platforms}|limit={int(limit)}"
    digest = hashlib.sha1(raw.encode("utf-8")).hexdigest()
    return f"search:{digest}"
