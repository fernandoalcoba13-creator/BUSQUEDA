import os
from urllib.parse import quote_plus

from bs4 import BeautifulSoup

from base import clean_text, extract_best_image, fetch_json, fetch_text, normalize_url

BASE_URL = "https://www.myminifactory.com"
API_BASE = "https://www.myminifactory.com/api/v2"
PLACEHOLDER = "/static/no-image.svg"


async def _search_api(query: str):
    api_key = os.getenv("MYMINIFACTORY_API_KEY", "").strip()
    if not api_key:
        return []

    url = f"{API_BASE}/search?q={quote_plus(query.strip())}&key={api_key}&per_page=12"
    try:
        data = await fetch_json(url, headers={"User-Agent": "KMORRA-STLGO/2.0"})
    except Exception as e:
        print(f"[myminifactory/api] error: {e}")
        return []

    results = []
    for item in data.get("items", []):
        image = PLACEHOLDER
        images = item.get("images", {}) or {}
        featured = images.get("featured")
        if isinstance(featured, list) and featured:
            image = featured[0].get("thumbnail", {}).get("url", PLACEHOLDER)
        elif isinstance(featured, dict):
            image = featured.get("thumbnail", {}).get("url", PLACEHOLDER)
        elif images.get("thumbnail"):
            image = images.get("thumbnail")

        price = "free"
        try:
            if item.get("price") and float(item.get("price", 0)) > 0:
                price = f"${item['price']}"
        except Exception:
            pass

        results.append(
            {
                "title": item.get("name", "Sin título"),
                "url": item.get("url", f"{BASE_URL}/object/3d-print-{item.get('id','')}"),
                "platform": "myminifactory",
                "image": image,
                "price": price,
                "_provider_position": len(results) + 1,
            }
        )
    return results


async def _search_html(query: str):
    url = f"{BASE_URL}/search/?query={quote_plus(query.strip())}"
    try:
        html = await fetch_text(url)
    except Exception as e:
        print(f"[myminifactory/html] error: {e}")
        return []

    soup = BeautifulSoup(html, "html.parser")
    results = []
    seen = set()

    for a in soup.find_all("a", href=True):
        href = a["href"]
        if "/object/3d-print-" not in href:
            continue
        full_url = normalize_url(href, BASE_URL)
        if not full_url or full_url in seen:
            continue
        seen.add(full_url)

        title = clean_text(a.get_text(" ", strip=True))
        if not title:
            title = full_url.rstrip("/").split("/")[-1].replace("-", " ").strip()

        image = extract_best_image(a, BASE_URL)
        if not image and a.parent:
            image = extract_best_image(a.parent, BASE_URL)

        text = clean_text(a.get_text(" ", strip=True)).lower()
        price = "free" if "free" in text else "unknown"

        results.append(
            {
                "title": title,
                "url": full_url,
                "platform": "myminifactory",
                "image": image or PLACEHOLDER,
                "price": price,
                "_provider_position": len(results) + 1,
            }
        )
        if len(results) >= 12:
            break
    return results


async def search(query: str):
    results = await _search_api(query)
    if not results:
        results = await _search_html(query)
    print(f"[myminifactory] '{query}' -> {len(results)} resultados")
    return results
