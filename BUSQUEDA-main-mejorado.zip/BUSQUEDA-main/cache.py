import asyncio
import json
import time
from pathlib import Path
from typing import Any, Optional

import aiosqlite

_DB_PATH = Path(__file__).resolve().parent / "search_cache.sqlite3"
_DEFAULT_TTL = 3600
_DB_READY = False
_DB_LOCK = asyncio.Lock()


async def _ensure_db() -> None:
    global _DB_READY
    if _DB_READY:
        return
    async with _DB_LOCK:
        if _DB_READY:
            return
        async with aiosqlite.connect(_DB_PATH) as db:
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS search_cache (
                    cache_key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    expires_at INTEGER NOT NULL,
                    created_at INTEGER NOT NULL
                )
                """
            )
            await db.execute(
                "CREATE INDEX IF NOT EXISTS idx_search_cache_expires ON search_cache(expires_at)"
            )
            await db.commit()
        _DB_READY = True


async def get_cached_results(cache_key: str) -> Optional[Any]:
    if not cache_key:
        return None
    await _ensure_db()
    now = int(time.time())
    async with aiosqlite.connect(_DB_PATH) as db:
        row = await db.execute_fetchone(
            "SELECT payload, expires_at FROM search_cache WHERE cache_key = ?",
            (cache_key,),
        )
        if not row:
            return None
        payload, expires_at = row
        if now > int(expires_at):
            await db.execute("DELETE FROM search_cache WHERE cache_key = ?", (cache_key,))
            await db.commit()
            return None
        return json.loads(payload)


async def set_cached_results(cache_key: str, results: Any, ttl: int = _DEFAULT_TTL) -> None:
    if not cache_key:
        return
    await _ensure_db()
    now = int(time.time())
    expires_at = now + int(ttl)
    payload = json.dumps(results, ensure_ascii=False)
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO search_cache(cache_key, payload, expires_at, created_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(cache_key) DO UPDATE SET
                payload = excluded.payload,
                expires_at = excluded.expires_at,
                created_at = excluded.created_at
            """,
            (cache_key, payload, expires_at, now),
        )
        await db.commit()


async def clear_cache() -> None:
    await _ensure_db()
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute("DELETE FROM search_cache")
        await db.commit()


async def purge_expired_cache() -> int:
    await _ensure_db()
    now = int(time.time())
    async with aiosqlite.connect(_DB_PATH) as db:
        cursor = await db.execute("DELETE FROM search_cache WHERE expires_at < ?", (now,))
        await db.commit()
        return cursor.rowcount or 0
