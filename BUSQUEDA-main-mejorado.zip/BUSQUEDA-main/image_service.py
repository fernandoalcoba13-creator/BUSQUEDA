import asyncio
import base64
import os
from pathlib import Path

from openai import OpenAI

from search_service import search_all


def _query_from_filename(image_path: str) -> str:
    stem = Path(image_path).stem.replace("_", " ").replace("-", " ").strip()
    return stem if stem else "3d printable model"


async def _detect_query_with_openai(image_path: str) -> str:
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY no configurada")

    prompt = (
        "Analiza esta imagen y devolvé solamente una consulta corta en inglés, ideal para buscar modelos STL o 3D printables relacionados. "
        "Máximo 8 palabras. Sin comillas ni explicación."
    )

    def _call() -> str:
        client = OpenAI(api_key=api_key)
        with open(image_path, "rb") as fh:
            encoded = base64.b64encode(fh.read()).decode("utf-8")
        response = client.responses.create(
            model=os.getenv("OPENAI_VISION_MODEL", "gpt-4.1-mini"),
            input=[
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": prompt},
                        {"type": "input_image", "image_url": f"data:image/jpeg;base64,{encoded}"},
                    ],
                }
            ],
        )
        return (response.output_text or "").strip()

    return await asyncio.to_thread(_call)


async def detect_query_from_image(image_path: str) -> str:
    try:
        detected = await _detect_query_with_openai(image_path)
        if detected:
            return detected
    except Exception as e:
        print(f"[image_service] vision fallback: {e}")
    return _query_from_filename(image_path)


async def search_by_image(image_path: str, filter_by: str = "all", platforms=None, limit: int = 30):
    detected_query = await detect_query_from_image(image_path)
    results = await search_all(
        query=detected_query,
        filter_by=filter_by,
        platforms=platforms,
        limit=limit,
    )

    clean_results = []
    for item in results:
        row = dict(item)
        row["_detected_query"] = detected_query
        clean_results.append(row)

    return clean_results
