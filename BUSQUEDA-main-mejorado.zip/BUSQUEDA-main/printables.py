from bs4 import BeautifulSoup

from base import clean_text, extract_best_image, fetch_text
from normalize import encode_q

BASE_URL = "https://www.printables.com"
PLACEHOLDER = "/static/no-image.svg"


async def search(query: str):
    url = f"{BASE_URL}/search/models?q={encode_q(query.strip())}"
    try:
        html = await fetch_text(url)
    except Exception as e:
        print(f"[printables] error: {e}")
        return []

    soup = BeautifulSoup(html, "html.parser")
    results = []
    seen = set()

    for a in soup.find_all("a", href=True):
        href = a["href"]
        if "/model/" not in href:
            continue
        full_url = href if href.startswith("http") else f"{BASE_URL}{href}"
        if full_url in seen:
            continue
        seen.add(full_url)

        title = clean_text(a.get_text(" ", strip=True))
        if not title:
            title = full_url.rstrip("/").split("/")[-1].replace("-", " ").strip()

        node = a
        image = extract_best_image(node, BASE_URL)
        if not image and a.parent:
            image = extract_best_image(a.parent, BASE_URL)

        results.append(
            {
                "title": title,
                "url": full_url,
                "platform": "printables",
                "image": image or PLACEHOLDER,
                "price": "free",
                "_provider_position": len(results) + 1,
            }
        )
        if len(results) >= 12:
            break

    print(f"[printables] '{query}' -> {len(results)} resultados")
    return results
