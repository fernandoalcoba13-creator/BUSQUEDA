# Kmorra Search API 3.0 — Manual de instalación

## Qué cambié
- Búsqueda paralela real con `httpx.AsyncClient`
- Cache persistente con SQLite
- Soporte para 5 plataformas: Thingiverse, Printables, MyMiniFactory, MakerWorld y Cults3D
- Mejor deduplicación y ranking
- Placeholder local para imágenes
- Proxy opcional de imágenes en `/api/image-proxy`
- Búsqueda por imagen con OpenAI Vision si configurás `OPENAI_API_KEY`

## Archivos importantes
- `main.py`: API principal
- `search_service.py`: orquestación de proveedores
- `image_service.py`: búsqueda por imagen
- `cache.py`: cache persistente
- `base.py`: cliente HTTP compartido
- `.env.example`: variables para tus APIs

## Variables de entorno
Copiá `.env.example` a `.env` y completá lo que uses.

### Mínimo recomendado
```env
PORT=8000
CORS_ALLOW_ORIGINS=*
OPENAI_API_KEY=tu_api_key
OPENAI_VISION_MODEL=gpt-4.1-mini
```

### Opcionales
- `THINGIVERSE_TOKEN`: solo si querés intentar usar API oficial
- `MYMINIFACTORY_API_KEY`: solo si tenés clave propia

## Instalación local
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

En Windows PowerShell:
```powershell
python -m venv venv
venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

## Deploy en servidor o Render
Tu `Procfile` ya puede seguir así:
```procfile
web: uvicorn main:app --host 0.0.0.0 --port $PORT
```

## Endpoints
### Salud
`GET /api/health`

### Buscar por texto
`GET /api/search?q=dragon&platforms=printables,cults3d&limit=24`

### Buscar por imagen
`POST /api/search-by-image`
- form-data: `image`
- query params opcionales: `filter`, `platforms`, `limit`

### Limpiar cache
`POST /api/cache/clear`

### Proxy de imagen
`GET /api/image-proxy?url=https://...`

## Cómo conectar tu frontend
En el frontend conviene usar esta lógica para la imagen:
```js
const imageUrl = item.image?.startsWith('http')
  ? `/api/image-proxy?url=${encodeURIComponent(item.image)}`
  : item.image || '/static/no-image.svg';
```

Y en el `<img>`:
```html
<img src="..." loading="lazy" decoding="async" onerror="this.src='/static/no-image.svg'" />
```

## Cómo subirlo a GitHub
```bash
git checkout -b mejora-busqueda-v3
git add .
git commit -m "Mejora completa de búsqueda, cache e imágenes"
git push origin mejora-busqueda-v3
```

## Recomendación de prueba
1. Probá `GET /api/health`
2. Probá `GET /api/search?q=articulated dragon`
3. Probá `POST /api/search-by-image` con una foto
4. Si la búsqueda por imagen no detecta bien, revisá que `OPENAI_API_KEY` esté cargada

## Observaciones reales
- Algunas plataformas cambian HTML seguido; por eso dejé fallback por HTML y por API donde aplica.
- Si una plataforma bloquea scraping, las otras siguen funcionando.
- El proxy de imagen ayuda mucho a que el frontend cargue miniaturas más estable.
