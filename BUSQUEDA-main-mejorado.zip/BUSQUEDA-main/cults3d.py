import re

from bs4 import BeautifulSoup

from base import clean_text, extract_best_image, fetch_text, normalize_url
from normalize import encode_q

BASE_URL = "https://cults3d.com"
PLACEHOLDER = "/static/no-image.svg"


async def search(query: str):
    url = f"{BASE_URL}/en/search?q={encode_q(query.strip())}"
    try:
        html = await fetch_text(url)
    except Exception as e:
        print(f"[cults3d] error: {e}")
        return []

    soup = BeautifulSoup(html, "html.parser")
    results = []
    seen = set()

    for a in soup.find_all("a", href=re.compile(r"/en/3d-model/")):
        href = a.get("href", "")
        full_url = normalize_url(href, BASE_URL)
        if not full_url or full_url in seen:
            continue
        seen.add(full_url)

        title = clean_text(a.get_text(" ", strip=True))
        if not title:
            title = full_url.rstrip("/").split("/")[-1].replace("-", " ").strip()

        image = extract_best_image(a, BASE_URL)
        if not image and a.parent:
            image = extract_best_image(a.parent, BASE_URL)

        price = "unknown"
        text = clean_text(a.get_text(" ", strip=True)).lower()
        if "free" in text:
            price = "free"
        else:
            m = re.search(r"(us\$\s?\d+(?:[\.,]\d+)?)", text, re.I)
            if m:
                price = m.group(1)

        results.append(
            {
                "title": title,
                "url": full_url,
                "platform": "cults3d",
                "image": image or PLACEHOLDER,
                "price": price,
                "_provider_position": len(results) + 1,
            }
        )
        if len(results) >= 12:
            break

    print(f"[cults3d] '{query}' -> {len(results)} resultados")
    return results
